from __future__ import absolute_import
from __future__ import unicode_literals
from __future__ import division
from __future__ import print_function

import os, itertools, random, argparse, time, datetime
import numpy as np
import random
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, explained_variance_score
from math import sqrt

import scipy.sparse as sp
from scipy.stats.stats import pearsonr
from models import *
from data import *

import shutil
import logging
import glob
import time
from tensorboardX import SummaryWriter

import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from dcrnn_model import *


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')  

ap = argparse.ArgumentParser()
ap.add_argument('--dataset', type=str, default='region785', help="Dataset string")
ap.add_argument('--sim_mat', type=str, default='region-adj', help="adjacency matrix filename (*-adj.txt)")
ap.add_argument('--n_layer', type=int, default=1, help="number of layers (default 1)")
ap.add_argument('--n_hidden', type=int, default=20, help="rnn hidden states (could be set as any value)")
ap.add_argument('--seed', type=int, default=42, help='random seed')
ap.add_argument('--epochs', type=int, default=1500, help='number of epochs to train')
ap.add_argument('--runs', type=int, default=3, help='number of repeated runs per model/horizon')
ap.add_argument('--lr', type=float, default=1e-3, help='initial learning rate')
ap.add_argument('--weight_decay', type=float, default=5e-4, help='weight decay (L2 loss on parameters).')
ap.add_argument('--dropout', type=float, default=0.2, help='dropout rate usually 0.2-0.5.')
ap.add_argument('--batch', type=int, default=32, help="batch size")
ap.add_argument('--check_point', type=int, default=1, help="check point")
ap.add_argument('--shuffle', action='store_true', default=False, help="not used, default false")
ap.add_argument('--train', type=float, default=.6, help="Training ratio (0, 1)")
ap.add_argument('--val', type=float, default=.2, help="Validation ratio (0, 1)")
ap.add_argument('--test', type=float, default=.2, help="Testing ratio (0, 1)")
ap.add_argument('--model', default='cola_gnn',
                choices=['cola_gnn', 'CNNRNN_Res', 'RNN', 'AR', 'ARMA', 'VAR', 'GAR',
                         'SelfAttnRNN', 'lstnet', 'stgcn', 'dcrnn'], help='')
ap.add_argument('--rnn_model', default='RNN', choices=['LSTM', 'RNN', 'GRU'], help='')
ap.add_argument('--mylog', action='store_false', default=True, help='save tensorboad log')
ap.add_argument('--cuda', action='store_true', default=False, help='')
ap.add_argument('--window', type=int, default=20, help='')
ap.add_argument('--horizon', type=int, default=1, help='leadtime default 1')
ap.add_argument('--save_dir', type=str, default='save', help='dir path to save the final model')
ap.add_argument('--gpu', type=int, default=3, help='choose gpu 0-10')
ap.add_argument('--lamda', type=float, default=0.01, help='regularize params similarities of states')
ap.add_argument('--bi', action='store_true', default=False, help='bidirectional default false')
ap.add_argument('--patience', type=int, default=100, help='patience default 100')
ap.add_argument('--k', type=int, default=10, help='kernels')
ap.add_argument('--hidsp', type=int, default=15, help='spatial dim')

args = ap.parse_args()
print('--------Parameters--------')
print(args)
print('--------------------------')

HORIZONS = [2, 3, 5, 10, 15]

METRIC_FIELDS = [
    'mae', 'std_mae', 'rmse', 'rmse_states', 'pcc', 'pcc_states',
    'r2', 'r2_states', 'var', 'var_states', 'peak_mae'
]

MODELS = [
    'cola_gnn', 'CNNRNN_Res', 'RNN', 'AR', 'ARMA', 'VAR', 'GAR',
    'SelfAttnRNN', 'lstnet', 'stgcn', 'dcrnn'
]

random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)

results_file = 'horizon_results_region.txt'
header_columns = ['dataset', 'model', 'window', 'horizon']
for metric_name in METRIC_FIELDS:
    header_columns.append('%s_mean' % metric_name)
    header_columns.append('%s_sd' % metric_name)

with open(results_file, 'w') as f:
    f.write('\t'.join(header_columns) + '\n')

os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)

args.cuda = args.cuda and torch.cuda.is_available()
logger.info('cuda %s', args.cuda)


def evaluate(data_loader, data, tag='val'):
    model.eval()
    total = 0.
    n_samples = 0.
    total_loss = 0.
    batch_size = args.batch
    y_pred_mx = []
    y_true_mx = []

    for inputs in data_loader.get_batches(data, batch_size, False):
        X, Y = inputs[0], inputs[1]
        output, _ = model(X)
        loss_train = F.l1_loss(output, Y)  
        total_loss += loss_train.item()
        n_samples += (output.size(0) * data_loader.m)

        y_true_mx.append(Y.data.cpu())
        y_pred_mx.append(output.data.cpu())

    y_pred_mx = torch.cat(y_pred_mx)
    y_true_mx = torch.cat(y_true_mx) 
    y_true_states = y_true_mx.numpy() * (data_loader.max - data_loader.min) * 1.0 + data_loader.min
    y_pred_states = y_pred_mx.numpy() * (data_loader.max - data_loader.min) * 1.0 + data_loader.min

    rmse_states = np.mean(
        np.sqrt(mean_squared_error(y_true_states, y_pred_states, multioutput='raw_values'))
    )
    raw_mae = mean_absolute_error(y_true_states, y_pred_states, multioutput='raw_values')
    std_mae = np.std(raw_mae)

    pcc_tmp = []
    for k in range(data_loader.m):
        pcc_tmp.append(pearsonr(y_true_states[:, k], y_pred_states[:, k])[0])
    pcc_states = np.mean(np.array(pcc_tmp))

    r2_states = np.mean(r2_score(y_true_states, y_pred_states, multioutput='raw_values'))
    var_states = np.mean(explained_variance_score(y_true_states, y_pred_states,
                                                  multioutput='raw_values'))

    # flatten for global metrics
    y_true = np.reshape(y_true_states, (-1))
    y_pred = np.reshape(y_pred_states, (-1))
    rmse = sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    pcc = pearsonr(y_true, y_pred)[0]
    r2 = r2_score(y_true, y_pred, multioutput='uniform_average')
    var = explained_variance_score(y_true, y_pred, multioutput='uniform_average')
    peak_mae = peak_error(y_true_states.copy(), y_pred_states.copy(), data_loader.peak_thold)

    global y_true_t
    global y_pred_t
    y_true_t = y_true_states
    y_pred_t = y_pred_states

    return float(total_loss / n_samples), mae, std_mae, rmse, rmse_states, \
        pcc, pcc_states, r2, r2_states, var, var_states, peak_mae


def train(data_loader, data):
    model.train()
    total_loss = 0.
    n_samples = 0.
    batch_size = args.batch

    for inputs in data_loader.get_batches(data, batch_size, True):
        X, Y = inputs[0], inputs[1]
        optimizer.zero_grad()
        output, _ = model(X)
        if Y.size(0) == 1:
            Y = Y.view(-1)
        loss_train = F.l1_loss(output, Y)
        total_loss += loss_train.item()
        loss_train.backward()
        optimizer.step()
        n_samples += (output.size(0) * data_loader.m)

    return float(total_loss / n_samples)


for model_name in MODELS:
    args.model = model_name

    for h in HORIZONS:
        args.horizon = h
        horizon_metrics = {metric: [] for metric in METRIC_FIELDS}

        for run_idx in range(args.runs):
            run_seed = args.seed + run_idx
            random.seed(run_seed)
            np.random.seed(run_seed)
            torch.manual_seed(run_seed)

            logger.info('=== Starting run for model %s, horizon %d (run %d/%d) ===',
                        model_name, h, run_idx + 1, args.runs)

            log_token = '%s.%s.w-%s.h-%s.%s.run-%d' % (
                args.model, args.dataset, args.window, args.horizon, args.rnn_model, run_idx + 1
            )

            if args.mylog:
                tensorboard_log_dir = 'tensorboard/%s' % log_token
                if not os.path.exists(tensorboard_log_dir):
                    os.makedirs(tensorboard_log_dir)
                writer = SummaryWriter(tensorboard_log_dir)
            else:
                writer = None

            data_loader = DataBasicLoader(args)

            if args.model == 'CNNRNN_Res':
                model = CNNRNN_Res(args, data_loader)
            elif args.model == 'RNN':
                model = RNN(args, data_loader)
            elif args.model == 'AR':
                model = AR(args, data_loader)
            elif args.model == 'ARMA':
                model = ARMA(args, data_loader)
            elif args.model == 'VAR':
                model = VAR(args, data_loader)
            elif args.model == 'GAR':
                model = GAR(args, data_loader)
            elif args.model == 'SelfAttnRNN':
                model = SelfAttnRNN(args, data_loader)
            elif args.model == 'lstnet':
                model = LSTNet(args, data_loader)
            elif args.model == 'stgcn':
                model = STGCN(args, data_loader, data_loader.m, 1, args.window, 1)
            elif args.model == 'dcrnn':
                model = DCRNNModel(args, data_loader)
            elif args.model == 'cola_gnn':
                model = cola_gnn(args, data_loader)
            else:
                raise LookupError('can not find the model')

            logger.info('model %s', model)
            if args.cuda:
                model.cuda()

            optimizer = torch.optim.Adam(
                filter(lambda p: p.requires_grad, model.parameters()),
                lr=args.lr,
                weight_decay=args.weight_decay
            )

            pytorch_total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
            print('#params:', pytorch_total_params)

            bad_counter = 0
            best_epoch = 0
            best_val = 1e+20

            try:
                print('begin training (model = %s, horizon = %d, run = %d)' %
                      (model_name, h, run_idx + 1))
                if not os.path.exists(args.save_dir):
                    os.makedirs(args.save_dir)

                for epoch in range(1, args.epochs + 1):
                    epoch_start_time = time.time()
                    train_loss = train(data_loader, data_loader.train)
                    val_loss, mae, std_mae, rmse, rmse_states, pcc, pcc_states, \
                        r2, r2_states, var, var_states, peak_mae = evaluate(
                            data_loader, data_loader.val
                        )

                    print('M {:>11s} | H {:2d} | Run {:2d} | Epoch {:3d}|time:{:5.2f}s|train_loss {:5.8f}|val_loss {:5.8f}'.format(
                        model_name, h, run_idx + 1, epoch, (time.time() - epoch_start_time), train_loss, val_loss))

                    if writer is not None:
                        writer.add_scalars('data/loss', {'train': train_loss}, epoch)
                        writer.add_scalars('data/loss', {'val': val_loss}, epoch)
                        writer.add_scalars('data/mae', {'val': mae}, epoch)
                        writer.add_scalars('data/rmse', {'val': rmse_states}, epoch)
                        writer.add_scalars('data/rmse_states', {'val': rmse_states}, epoch)
                        writer.add_scalars('data/pcc', {'val': pcc}, epoch)
                        writer.add_scalars('data/pcc_states', {'val': pcc_states}, epoch)
                        writer.add_scalars('data/R2', {'val': r2}, epoch)
                        writer.add_scalars('data/R2_states', {'val': r2_states}, epoch)
                        writer.add_scalars('data/var', {'val': var}, epoch)
                        writer.add_scalars('data/var_states', {'val': var_states}, epoch)
                        writer.add_scalars('data/peak_mae', {'val': peak_mae}, epoch)

                    if val_loss < best_val:
                        best_val = val_loss
                        best_epoch = epoch
                        bad_counter = 0
                        model_path = '%s/%s.pt' % (args.save_dir, log_token)
                        with open(model_path, 'wb') as f:
                            torch.save(model.state_dict(), f)
                        print('Best validation epoch (model=%s, h=%d, run=%d): %d %s' %
                              (model_name, h, run_idx + 1, epoch, time.ctime()))

                        test_loss, mae, std_mae, rmse, rmse_states, pcc, pcc_states, \
                            r2, r2_states, var, var_states, peak_mae = evaluate(
                                data_loader, data_loader.test, tag='test'
                            )

                        print(
                            'TEST (model={:>11s}, h={:d}, run={:d}) MAE {:5.4f} std {:5.4f} RMSE {:5.4f} RMSEs {:5.4f} '
                            'PCC {:5.4f} PCCs {:5.4f} R2 {:5.4f} R2s {:5.4f} Var {:5.4f} '
                            'Vars {:5.4f} Peak {:5.4f}'.format(
                                model_name, h, run_idx + 1, mae, std_mae, rmse, rmse_states,
                                pcc, pcc_states, r2, r2_states, var, var_states, peak_mae
                            )
                        )
                    else:
                        bad_counter += 1

                    if bad_counter == args.patience:
                        break

            except KeyboardInterrupt:
                print('-' * 89)
                print('Exiting from training early, epoch', epoch,
                      'for model', model_name, 'horizon', h, 'run', run_idx + 1)

            model_path = '%s/%s.pt' % (args.save_dir, log_token)
            with open(model_path, 'rb') as f:
                model.load_state_dict(torch.load(f))

            test_loss, mae, std_mae, rmse, rmse_states, pcc, pcc_states, \
                r2, r2_states, var, var_states, peak_mae = evaluate(
                    data_loader, data_loader.test, tag='test'
                )

            print('Final evaluation (model=%s, h=%d, run=%d)' % (model_name, h, run_idx + 1))
            print(
                'TEST MAE {:5.4f} std {:5.4f} RMSE {:5.4f} RMSEs {:5.4f} '
                'PCC {:5.4f} PCCs {:5.4f} R2 {:5.4f} R2s {:5.4f} Var {:5.4f} '
                'Vars {:5.4f} Peak {:5.4f}'.format(
                    mae, std_mae, rmse, rmse_states,
                    pcc, pcc_states, r2, r2_states, var, var_states, peak_mae
                )
            )

            metric_values = {
                'mae': mae,
                'std_mae': std_mae,
                'rmse': rmse,
                'rmse_states': rmse_states,
                'pcc': pcc,
                'pcc_states': pcc_states,
                'r2': r2,
                'r2_states': r2_states,
                'var': var,
                'var_states': var_states,
                'peak_mae': peak_mae
            }
            for metric_name, metric_val in metric_values.items():
                horizon_metrics[metric_name].append(metric_val)

            if writer is not None:
                writer.close()

        summary_line = ['Aggregated metrics (model=%s, h=%d)' % (model_name, h)]
        line_values = [args.dataset, args.model, str(args.window), str(h)]
        for metric_name in METRIC_FIELDS:
            metric_array = np.array(horizon_metrics[metric_name], dtype=np.float64)
            mean_val = float(np.mean(metric_array))
            std_val = float(np.std(metric_array))
            summary_line.append('%s %.4f+/-%.4f' % (metric_name, mean_val, std_val))
            line_values.append('%.6f' % mean_val)
            line_values.append('%.6f' % std_val)

        print(' | '.join(summary_line))

        with open(results_file, 'a') as f:
            f.write('\t'.join(line_values) + '\n')
