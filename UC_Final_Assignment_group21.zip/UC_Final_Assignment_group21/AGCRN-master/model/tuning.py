import argparse
import configparser
import copy
import csv
import os
import statistics
import sys
from datetime import datetime
from types import SimpleNamespace

import torch
import torch.nn as nn

file_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(file_dir)

from model.AGCRN import AGCRN as Network  
from model.BasicTrainer import Trainer  
from lib.TrainInits import init_seed, print_model_parameters  
from lib.dataloader import get_dataloader  
from lib.metrics import MAE_torch  


def masked_mae_loss(scaler, mask_value):
    def loss(preds, labels):
        if scaler:
            preds = scaler.inverse_transform(preds)
            labels = scaler.inverse_transform(labels)
        return MAE_torch(pred=preds, true=labels, mask_value=mask_value)

    return loss


def parse_optional_float(value):
    if value is None:
        return None
    string_value = str(value).strip()
    if string_value.lower() == "none":
        return None
    return float(string_value)


def cli_parser():
    parser = argparse.ArgumentParser(description="Ablation runner (one hyperparameter at a time)")
    parser.add_argument("--dataset", default="ILIREGIONS", type=str)
    parser.add_argument("--model", default="AGCRN", type=str)
    parser.add_argument("--device", default="cuda", type=str)
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug logging and skip writing checkpoints")
    parser.add_argument("--epochs", default=None, type=int,
                        help="Override epoch count from the config")

    parser.add_argument("--output-dir", default=None, type=str,
                        help="Directory where logs/checkpoints/results are stored")
    parser.add_argument("--seed", default=42, type=int,
                        help="Base seed; each repeat adds repeat_idx")

    parser.add_argument("--skip-test", action="store_true",
                        help="Skip test/eval phase (default: run test)")

    parser.add_argument("--repeats", default=3, type=int,
                        help="Independent runs per configuration")

    parser.add_argument("--only-param", default=None, type=str,
                        choices=["lag", "embed_dim", "rnn_units", "num_layers", "lr_init"],
                        help="Run ablation for only this parameter")

    return parser.parse_args()


def load_config(dataset, model_name):
    config_path = os.path.join(file_dir, "model", f"{dataset}_{model_name}.conf")
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Could not locate config file at {config_path}")
    config = configparser.ConfigParser()
    config.read(config_path)
    return config


def build_base_args(cli_args, config):
    data_cfg = config["data"]
    model_cfg = config["model"]
    train_cfg = config["train"]
    test_cfg = config["test"]
    log_cfg = config["log"]

    args = SimpleNamespace()
    args.dataset = cli_args.dataset
    args.mode = "train"
    args.device = cli_args.device
    args.debug = cli_args.debug
    args.model = cli_args.model
    args.cuda = torch.cuda.is_available() and "cuda" in cli_args.device

    args.val_ratio = data_cfg.getfloat("val_ratio")
    args.test_ratio = data_cfg.getfloat("test_ratio")
    args.lag = data_cfg.getint("lag")
    args.horizon = data_cfg.getint("horizon")
    args.num_nodes = data_cfg.getint("num_nodes")
    args.tod = data_cfg.getboolean("tod")
    args.normalizer = data_cfg.get("normalizer")
    args.column_wise = data_cfg.getboolean("column_wise")
    args.default_graph = data_cfg.getboolean("default_graph")

    args.input_dim = model_cfg.getint("input_dim")
    args.output_dim = model_cfg.getint("output_dim")
    args.embed_dim = model_cfg.getint("embed_dim")
    args.rnn_units = model_cfg.getint("rnn_units")
    args.num_layers = model_cfg.getint("num_layers")
    args.cheb_k = model_cfg.getint("cheb_order")

    args.loss_func = train_cfg.get("loss_func")
    args.seed = train_cfg.getint("seed")
    args.batch_size = train_cfg.getint("batch_size")
    args.epochs = cli_args.epochs if cli_args.epochs else train_cfg.getint("epochs")
    args.lr_init = train_cfg.getfloat("lr_init")
    args.lr_decay = train_cfg.getboolean("lr_decay")
    args.lr_decay_rate = train_cfg.getfloat("lr_decay_rate")
    args.lr_decay_step = train_cfg.get("lr_decay_step")
    args.early_stop = train_cfg.getboolean("early_stop")
    args.early_stop_patience = train_cfg.getint("early_stop_patience")
    args.grad_norm = train_cfg.getboolean("grad_norm")
    args.max_grad_norm = train_cfg.getint("max_grad_norm")

    args.teacher_forcing = False
    args.real_value = train_cfg.getboolean("real_value")

    args.mae_thresh = parse_optional_float(test_cfg.get("mae_thresh"))
    args.mape_thresh = test_cfg.getfloat("mape_thresh")

    args.log_dir = ""
    args.log_step = log_cfg.getint("log_step")
    args.epoch_log_interval = 100 
    args.show_best_saves = False   
    args.plot = log_cfg.getboolean("plot")

    args.skip_test = cli_args.skip_test
    return args


def create_loss(loss_name, scaler, args):
    if loss_name == "mask_mae":
        return masked_mae_loss(scaler, mask_value=0.0)
    if loss_name == "mae":
        return torch.nn.L1Loss().to(args.device)
    if loss_name == "mse":
        return torch.nn.MSELoss().to(args.device)
    raise ValueError(f"Unsupported loss function: {loss_name}")


def _unique_keep_order(seq):
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def four_values_around_default(default, param_name: str):
    if param_name == "lr_init":
        vals = [default / 2.0, default / 1.5, default * 1.5, default * 2.0]
        vals = [float(v) for v in vals if v > 0]
        return _unique_keep_order(vals)

    mults = [0.5, 0.75, 1.25, 1.5]
    raw = [default * m for m in mults]

    if param_name in ("lag", "num_layers", "embed_dim", "rnn_units"):
        vals = [max(1, int(round(v))) for v in raw]
        vals = _unique_keep_order(vals)

        while len(vals) < 4:
            next_v = max(vals[-1] + 1, int(round(default * (1.5 + 0.25 * (len(vals) - 3)))))
            vals.append(next_v)
            vals = _unique_keep_order(vals)

        return vals[:4]


def run_single_training(args):
    init_seed(args.seed)

    model = Network(args).to(args.device)

    for param in model.parameters():
        if param.dim() > 1:
            nn.init.xavier_uniform_(param)
        else:
            nn.init.uniform_(param)

    print_model_parameters(model, only_num=True)

    train_loader, val_loader, test_loader, scaler = get_dataloader(
        args,
        normalizer=args.normalizer,
        tod=args.tod,
        dow=False,
        weather=False,
        single=False,
    )

    loss = create_loss(args.loss_func, scaler, args)

    optimizer = torch.optim.Adam(
        params=model.parameters(),
        lr=args.lr_init,
        eps=1.0e-8,
        weight_decay=0.0,
        amsgrad=False,
    )

    lr_scheduler = None
    if args.lr_decay:
        milestones = [int(step) for step in args.lr_decay_step.split(",") if step.strip()]
        lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(
            optimizer=optimizer,
            milestones=milestones,
            gamma=args.lr_decay_rate,
        )

    trainer = Trainer(
        model,
        loss,
        optimizer,
        train_loader,
        val_loader,
        test_loader,
        scaler,
        args,
        lr_scheduler=lr_scheduler,
    )

    best_loss, test_metrics = trainer.train()

    best_model_path = trainer.best_path if not args.debug else None
    return best_loss, best_model_path, test_metrics


def aggregate_metrics(metrics_list, key):
    vals = [m[key] for m in metrics_list if m is not None and key in m]
    if not vals:
        return None, None
    mean = statistics.fmean(vals)
    std = statistics.stdev(vals) if len(vals) > 1 else 0.0
    return mean, std


def run_ablation_for_param(param_name, base_args, cli_args, output_dir):
    default_value = getattr(base_args, param_name)
    values = four_values_around_default(default_value, param_name)

    results_rows = []

    for v in values:
        exp_name = f"{param_name}={v}"
        exp_dir = os.path.join(output_dir, param_name, exp_name)
        os.makedirs(exp_dir, exist_ok=True)

        repeat_losses = []
        repeat_metrics = []
        repeat_models = []

        for repeat_idx in range(cli_args.repeats):
            args = copy.deepcopy(base_args)
            setattr(args, param_name, v)

            args.seed = cli_args.seed + repeat_idx
            args.log_dir = os.path.join(exp_dir, f"repeat_{repeat_idx:02d}")
            os.makedirs(args.log_dir, exist_ok=True)

            best_loss, best_model_path, test_metrics = run_single_training(args)

            repeat_losses.append(best_loss)
            repeat_metrics.append(test_metrics)
            repeat_models.append(best_model_path)

        mean_loss = statistics.fmean(repeat_losses)
        std_loss = statistics.stdev(repeat_losses) if len(repeat_losses) > 1 else 0.0

        mean_mae, std_mae = aggregate_metrics(repeat_metrics, "mae")
        mean_rmse, std_rmse = aggregate_metrics(repeat_metrics, "rmse")
        mean_mape, std_mape = aggregate_metrics(repeat_metrics, "mape")
        mean_pcc, std_pcc = aggregate_metrics(repeat_metrics, "pcc")

        row = {
            "param": param_name,
            "default": default_value,
            "value": v,
            "repeats": cli_args.repeats,
            "val_loss_mean": mean_loss,
            "val_loss_std": std_loss,
            "test_mae_mean": mean_mae,
            "test_mae_std": std_mae,
            "test_rmse_mean": mean_rmse,
            "test_rmse_std": std_rmse,
            "test_mape_mean": mean_mape,
            "test_mape_std": std_mape,
            "test_pcc_mean": mean_pcc,
            "test_pcc_std": std_pcc,
            "exp_dir": exp_dir,
        }
        results_rows.append(row)

        print(f"[{param_name}] value={v}  val_loss={mean_loss:.6f}±{std_loss:.6f}  "
              f"test_rmse={mean_rmse if mean_rmse is not None else 'NA'}")

    return results_rows


def main():
    cli_args = cli_parser()
    config = load_config(cli_args.dataset, cli_args.model)
    base_args = build_base_args(cli_args, config)

    current_dir = os.path.dirname(os.path.realpath(__file__))
    default_output = os.path.join(current_dir, "experiments", f"{cli_args.dataset}_ablation")
    output_dir = cli_args.output_dir if cli_args.output_dir else default_output
    os.makedirs(output_dir, exist_ok=True)

    params = ["lag", "embed_dim", "rnn_units", "num_layers", "lr_init"]
    if cli_args.only_param is not None:
        params = [cli_args.only_param]

    all_rows = []
    started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"Starting ablation at {started}")
    print(f"Output dir: {output_dir}")
    print(f"Test phase: {'SKIPPED' if cli_args.skip_test else 'RUN'}")
    print(f"Repeats: {cli_args.repeats}")
    print(f"Defaults: lag={base_args.lag}, embed_dim={base_args.embed_dim}, "
          f"rnn_units={base_args.rnn_units}, num_layers={base_args.num_layers}, lr_init={base_args.lr_init}")

    for p in params:
        rows = run_ablation_for_param(p, base_args, cli_args, output_dir)
        all_rows.extend(rows)

    csv_path = os.path.join(output_dir, "ablation_results.csv")
    fieldnames = [
        "param", "default", "value", "repeats",
        "val_loss_mean", "val_loss_std",
        "test_mae_mean", "test_mae_std",
        "test_rmse_mean", "test_rmse_std",
        "test_mape_mean", "test_mape_std",
        "test_pcc_mean", "test_pcc_std",
        "exp_dir",
    ]
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            writer.writerow(row)

    print(f"\nWrote: {csv_path}")


if __name__ == "__main__":
    main()
