import torch
import torch.nn.functional as F
import torch.nn as nn

class AVWGCN(nn.Module):
    def __init__(self, dim_in, dim_out, cheb_k, embed_dim):
        super(AVWGCN, self).__init__()
        self.cheb_k = cheb_k
        self.weights_pool = nn.Parameter(torch.FloatTensor(embed_dim, cheb_k, dim_in, dim_out))
        self.bias_pool = nn.Parameter(torch.FloatTensor(embed_dim, dim_out))
    def forward(self, x, node_embeddings):
        # x: [B, N, dim_in]
        # node_embeddings: [N, embed_dim]
        device = x.device
        node_embeddings = node_embeddings.to(device)

        node_num = node_embeddings.shape[0]

        # supports: [N, N] on device
        supports = F.softmax(
            F.relu(torch.mm(node_embeddings, node_embeddings.transpose(0, 1))),
            dim=1
        )

        # Chebyshev supports: list of [N, N] on device
        support_set = [torch.eye(node_num, device=device), supports]
        for k in range(2, self.cheb_k):
            support_set.append(torch.matmul(2 * supports, support_set[-1]) - support_set[-2])
        supports = torch.stack(support_set, dim=0)  # [K, N, N]

        # weights: [N, K, dim_in, dim_out], bias: [N, dim_out] on device
        weights = torch.einsum('nd,dkio->nkio', node_embeddings, self.weights_pool)
        bias = torch.matmul(node_embeddings, self.bias_pool)

        # graph convolution
        x_g = torch.einsum("knm,bmc->bknc", supports, x)   # [B, K, N, dim_in]
        x_g = x_g.permute(0, 2, 1, 3)                     # [B, N, K, dim_in]
        x_gconv = torch.einsum('bnki,nkio->bno', x_g, weights) + bias  # [B, N, dim_out]
        return x_gconv
